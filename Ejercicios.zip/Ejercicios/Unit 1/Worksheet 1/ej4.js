num1 = 4;
num2 = 2;
document.write("El valor de la primera variable es " + num1 + "<br>");
document.write("El valor de la segunda variable es " + num2 + "<br>");
document.write("La suma es: " + (num1 + num2) + "<br>");
document.write("La resta es: " + (num1 - num2) + "<br>");
document.write("La multiplicacion es: " + (num1 * num2) + "<br>");
document.write("La division es: " + (num1 / num2));