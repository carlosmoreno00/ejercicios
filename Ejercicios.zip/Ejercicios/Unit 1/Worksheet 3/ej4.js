function calcCircumference(radius) {
    var circumference = 2 * Math.PI * radius;
    document.write("The circumference is " + circumference + "<br>");
}
function calcArea(radius) {
    var area = Math.PI * Math.pow(radius,2);
    document.write("The area is " + area + "<br>");
}