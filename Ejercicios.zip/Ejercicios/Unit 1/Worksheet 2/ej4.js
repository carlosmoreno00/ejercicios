var celsius = 30;
var fahrenheit = celsius * 9 / 5 + 32;
document.write(celsius + " ºC is " + fahrenheit + " ºF <br>");
var fahrenheit1 = 50;
var celsius1 = (fahrenheit1-32) / 9 * 5;
document.write(fahrenheit1 + " ºF is " + celsius1 + " ºC");
