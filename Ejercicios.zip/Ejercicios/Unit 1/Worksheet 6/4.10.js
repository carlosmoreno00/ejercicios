var texto = "Cabecera h";
document.write("<h1>PRACTICA DE BUCLE FOR</h1>");
for (i=1;i<7;i++){
    document.write("<h"+i+">"+texto+i+"</h"+i+">");
}