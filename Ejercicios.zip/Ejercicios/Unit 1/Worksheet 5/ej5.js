var edad = prompt("Introduce una edad");
if (edad > 17)
    document.write("Es mayor de edad");
else
    document.write("Es menor de edad");