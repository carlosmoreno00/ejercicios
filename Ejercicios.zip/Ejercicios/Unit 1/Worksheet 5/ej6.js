var edad = prompt("Escriba la edad de un usuario");
var localidad = prompt("Escribe su localidad de nacimiento");
if (edad > 25 && localidad == 'Madrid')
    document.write("Enhorabuena");