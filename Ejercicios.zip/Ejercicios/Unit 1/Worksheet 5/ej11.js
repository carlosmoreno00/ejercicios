var edad = prompt("Escriba la edad de un usuario");
if (edad < 67)
    document.write("No puede jubilarse todavia");
else
    document.write("Puede jubilarse ya");