var palabra = prompt("Escribe una palabra");
for (; palabra != 'SALIR';) {
    document.write(palabra + "<br>");
    palabra = prompt("Escribe una palabra");
}