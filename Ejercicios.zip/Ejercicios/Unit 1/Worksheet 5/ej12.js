var edad = prompt("Escribe una edad");
if (edad < 6)
    document.write("Debes estar en el jardin de infancia");
else if (edad < 12)
    document.write("Debes estar en primaria");
else if (edad < 17)
    document.write("Debes estar en la ESO");
else if (edad < 22)
    document.write("Debes estar en Bachillerato o en Ciclos");
else
    document.write("Debes estar en la Universidad");