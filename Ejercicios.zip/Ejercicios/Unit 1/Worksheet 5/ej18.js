for (var i = 1; i < 11; i++) {
    document.write(i + "<hr>");
}