var numero = prompt("Escribe un numero");
for (var i = numero; i<101; i++) {
    document.write(i + " ");
}