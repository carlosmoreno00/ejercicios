var numero = prompt("Introduce un numero");
var suma = 0;
for (var i = 1; i < 11; i++) {
    var suma =+ numero;
    var numero = prompt("Introduce un numero");
}
document.write("La suma es " + suma);