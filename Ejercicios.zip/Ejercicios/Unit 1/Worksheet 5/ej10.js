var nombre = prompt("Escribe su nombre");
var apellidos = prompt("Escribe sus apellidos");
if (nombre == 'Ricardo')
    alert("Los apellidos son " + apellidos)
else
    document.write("Los apellidos son " + apellidos);
