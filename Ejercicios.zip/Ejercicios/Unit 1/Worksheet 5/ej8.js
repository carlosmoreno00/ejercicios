var nombre = prompt("Escribe un nombre");
if (nombre == 'Pablo' || nombre == 'Eduardo')
    document.write("Bienvenido");
else if (nombre == 'Ana' || nombre == 'Clara')
    document.write("Bienvenida");
else
    document.write("No has introducido un nombre valido");