var nombre = prompt("Escribe tu nombre");
var apellidos = prompt("Escribe tus apellidos");
var edad = prompt("Escribe tu edad");
var ciclo = prompt("Escribe el ciclo que estudias");
alert(nombre + " " + apellidos + " de " + edad + " años estudia " + ciclo);