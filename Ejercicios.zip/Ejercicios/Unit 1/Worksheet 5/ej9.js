var edad = prompt("Escribe la edad de un usuario");
var ciudad = prompt("Escribe la ciuda donde vive");
if (ciudad == 'Madrid' && edad > 17 && edad < 31)
    document.write("Puede acceder al carnet de empresarios emprendedores");