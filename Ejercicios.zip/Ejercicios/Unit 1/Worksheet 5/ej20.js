var numero = prompt("Escribe un numero");
for (; numero != 0;) {
    numero = prompt("Escribe un numero");
}