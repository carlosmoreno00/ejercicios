var numero = prompt("Introduce un numero");
if (numero % 2 == 0)
    document.write(numero + " es par");
else
    document.write(numero + " es impar");