var nombre = prompt("Dime tu nombre");
document.write("Hola " + nombre);