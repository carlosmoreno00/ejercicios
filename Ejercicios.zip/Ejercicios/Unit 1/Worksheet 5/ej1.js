var nombre = prompt("Dime tu nombre");
var apellidos = prompt("Dime tus apellidos");
var edad = prompt("Dime tu edad");
document.write("<p>" + nombre + "</p>");
document.write("<p>" + apellidos + "</p>");
document.write("<p>" + edad + "</p>");