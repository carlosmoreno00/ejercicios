var fecha = new Date();
document.write(fecha.getFullYear()+'<br>');
document.write(fecha.getMonth()+'<br>');
document.write(fecha.getDate()+'<br>');
document.write(fecha.getHours()+'<br>');
document.write(fecha.getMinutes()+'<br>');
document.write(fecha.getSeconds()+'<br>');