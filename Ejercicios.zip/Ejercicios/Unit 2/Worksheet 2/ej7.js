document.write("<h3>Numero --- Seno</h3>");
document.write("0 --- " + Math.sin(0));
document.write("<br>90 --- " + Math.sin(90));
document.write("<br>180 --- " + Math.sin(180));
document.write("<br>270 --- " + Math.sin(270));
document.write("<br>360 --- " + Math.sin(360));